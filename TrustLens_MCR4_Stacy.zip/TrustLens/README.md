# COE70A-B-Capstone — TrustLens

TrustLens is a phishing-triage Chrome extension. This repo combines:

- **Cristian's extension prototype (MCR1):** popup, "Scan this page", saved scan files (`scan.json`, `page.html.txt`, `screenshot.png`) and a low/medium/high triage score. The write-up and sample scans are in `deliverables/cristian_mcr1/`.
- **Stacy's Branch B (MCR1):** URL, HTML/DOM and visible-text analysis with unit tests and an evaluation corpus. The original Python is in `python/trustlens_branch_b/`. A JavaScript port runs inside the extension.

## Layout

```
extension/                  Load this folder in chrome://extensions ("Load unpacked")
  manifest.json             MV3; permissions: activeTab, scripting, downloads
  popup.html/.css/.js       Popup: scan, show both results, save files
  lib/collect.js            Runs in the page and gathers the scan.json indicators + HTML
  lib/heuristics.js         Prototype points score -> low / medium / high
  lib/branch_b.js           Branch B analyzer (JS port of url_html_text_branch.py)
  lib/html_parser.js        Tokenizer matching Python's html.parser
  lib/pyport.js             difflib ratio, urlparse, unquote, parse_qs ports
  selftest/                 Branch B tests + evaluation, runnable inside the extension
python/trustlens_branch_b/  Stacy's original Python module, tests, evaluate.py
tests/                      Node test runner (unit, parity, heuristics)
deliverables/cristian_mcr1/ Prototype write-up PDF + saved nike.com / adidas.ca scans
```

## Using the extension

1. Open `chrome://extensions`, turn on Developer mode, then click **Load unpacked** and pick the `extension/` folder.
2. On any http(s) page, click the TrustLens icon and then **Scan this page**. The popup shows:
   - **Prototype triage**: points, level and reasons.
   - **Branch B**: `risk_score`, `label_hint`, `confidence`, `missing` and the weighted evidence list.
3. With "Save scan files" ticked, the files go to `Downloads/PhishScans/<host>_<timestamp>/`. `scan.json` now also holds `heuristics` and `branchB`, the shared branch-schema output for fusion.
4. Click **Run self-tests** in the popup to run Branch B's unit tests and evaluation corpus inside Chrome. These use the same analyzer code the popup uses.

## Tests

```
npm test          # JS: Branch B unit tests, Python<->JS parity, prototype heuristics
npm run test:py   # Python: Stacy's original unittest suite
npm run evaluate  # Branch B precision / recall / FPR (JS port of evaluate.py)
```

- `tests/branch_b.test.js` runs the same cases as the in-extension self-test page (`extension/selftest/branch_b.cases.js`). These are a 1:1 port of `test_branch.py`.
- `tests/parity.test.js` checks that the JS analyzer gives the same evidence, weights and scores as the Python one. It covers 29 cases, including Cristian's real nike.com and adidas.ca pages. **If you change the Python analyzer, make the same change in `extension/lib/branch_b.js`, then run `npm run parity:update`**. The test fails if the two drift apart.
- `tests/heuristics.test.js` checks that the prototype score reproduces the scores stored in Cristian's saved scans.

No dependencies: Node 18+ and Python 3 standard library only.

## MCR II / III additions (Stacy, Branch B)

- **Fixture format = Daniel's corpus.** A local test page carries its metadata on `<html>`:
  `data-page-id="P02" data-intended-url="https://..." data-claimed-brand="..."`. When the page is served from `localhost`, `127.0.0.1` or `file://`, Branch B runs its URL/domain rules on `data-intended-url`, so localhost is never the evidence. The older `<meta name="trustlens:intended-url">` tag is still read. On a public host the attributes are ignored and reported as `html.fixture_tag_on_public_page`, so a real phishing page can't use them to pose as another site. `data-claimed-brand` is a test label only and is never used as evidence.
- **Output fields.** `analyzed_url`, `url_source` (`page`, `manifest`, `fixture_meta`, `local_unscored`), `claims`, and `fixture` (`page_id`, `claimed_brand`) for test pages.
- **Shared evidence format (the team's converter).** `shared_adapter.py` / `extension/lib/shared_adapter.js` convert Branch B output into fusion schema v0.1.0: one object each for `url`, `dom` and `text`. All three carry `"source": "branch_b"` because they come from one analysis of one page; fusion should not treat them as three independent opinions. `page_id` defaults to the fixture's `data-page-id`. Evidence with no fusion type yet is kept in `features`. The popup saves this as `branchBShared` in `scan.json`, with a `requestId`.
- **Corpus runner.** `python3 python/trustlens_branch_b/run_corpus.py <Daniel's corpus folder> --out results` runs Branch B on every page in `test_corpus_inventory.csv`, labels each page correct / missed / falsely flagged, and writes `results/branch_b_corpus_report.md` plus `results/<page_id>.branch_b.json` in the shared format.
- **End to end with fusion.** `python3 python/trustlens_branch_b/demo_with_fusion.py <path to trustlens_fusion> --corpus <Daniel's corpus folder>` sends each corpus page through Branch B and Derek's `fuse()` (visual marked missing). Without `--corpus` it runs the built-in unit cases.
- **Results (`results/`).** Branch B on Daniel's corpus: `branch_b_corpus_report.md` (correct / missed / falsely flagged, fired rules, notes), one shared-format file per page, and `fusion_on_corpus.txt` (the same pages through fusion, with each pipeline step labelled implemented / not used / unavailable).
- **New rule `html.shortened_link`.** Links inside a page that go through a URL shortener (bit.ly, tinyurl.com, ...) are reported once per page: 0.15, plus 0.05 per extra link, capped at 0.3.
- **Tests.** 38 Python tests (14 original + 24 MCR II/III) and 79 JS tests (unit, MCR II/III, parity on 37 inputs including the converter output, heuristics).
