"""Run Branch B over the team's fixture corpus and report correct / missed / falsely flagged.

    python3 run_corpus.py <corpus folder>
    python3 run_corpus.py <corpus folder> --out results

<corpus folder> is Daniel's corpus layout:
    test_corpus_inventory.csv     page_id, filename, claimed_brand, intended_url, scenario, ...
    test_pages/<filename>         each page carries data-page-id / data-intended-url on <html>
    expected_evidence/expected_results.json   (optional) expected_scenario per page

Each page is analyzed as the extension would see it: served from 127.0.0.1, with
its intended URL read from the page's data-intended-url attribute (the inventory's
intended_url is used only if the page has none, and a mismatch is reported).

Expected label: a page whose expected_scenario (or scenario) starts with
"suspicious" is phishing-style (1); every other page is legitimate-style (0).

Verdict per page:
    phishing-style page:   suspicious -> correct,  uncertain -> missed (uncertain),  safe -> missed
    legitimate-style page: safe -> correct,  uncertain -> uncertain (not flagged),  suspicious -> falsely flagged

With --out, writes <out>/branch_b_corpus_report.md and <out>/<page_id>.branch_b.json
(the page's Branch B output in the shared evidence format, ready for fusion).
"""
import csv
import json
import os
import sys

from url_html_text_branch import analyze
from shared_adapter import to_shared


def load_inventory(folder):
    with open(os.path.join(folder, "test_corpus_inventory.csv"), newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    expected = {}
    path = os.path.join(folder, "expected_evidence", "expected_results.json")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            expected = {t["page_id"]: t.get("expected_scenario", "") for t in json.load(f).get("tests", [])}
    return rows, expected


def verdict(label, hint):
    if label == 1:
        return {"suspicious": "correct", "uncertain": "missed (uncertain)"}.get(hint, "missed")
    return {"safe": "correct", "uncertain": "uncertain (not flagged)"}.get(hint, "falsely flagged")


def run(folder):
    rows, expected = load_inventory(folder)
    results = []
    for row in rows:
        pid = row["page_id"]
        with open(os.path.join(folder, "test_pages", row["filename"]), encoding="utf-8") as f:
            html = f.read()
        local = "http://127.0.0.1:8000/test_pages/" + row["filename"]
        r = analyze(local, html)
        note = ""
        if r["url_source"] == "local_unscored" and row.get("intended_url"):
            r = analyze(local, html, intended_url=row["intended_url"])
            note = "page has no data-intended-url; inventory URL used"
        elif r["analyzed_url"] != row.get("intended_url", r["analyzed_url"]):
            note = f"page URL {r['analyzed_url']} differs from inventory {row['intended_url']}"
        scenario = expected.get(pid) or row.get("scenario", "")
        label = 1 if scenario.lower().startswith("suspicious") else 0
        results.append({"page_id": pid, "scenario": scenario, "label": label, "result": r,
                        "verdict": verdict(label, r["label_hint"]), "note": note,
                        "shared": to_shared(r, request_id="corpus-" + pid, page_id=pid)})
    return results


def summary(results):
    c = {k: 0 for k in ("tp", "fp", "tn", "fn")}
    for x in results:
        pred = x["result"]["label_hint"] == "suspicious"
        key = ("tp" if pred else "fn") if x["label"] else ("fp" if pred else "tn")
        c[key] += 1
    c["precision"] = c["tp"] / (c["tp"] + c["fp"]) if c["tp"] + c["fp"] else None
    c["recall"] = c["tp"] / (c["tp"] + c["fn"]) if c["tp"] + c["fn"] else None
    return c


def report_md(results, c):
    fmt = lambda v: "n/a" if v is None else f"{v:.2f}"  # noqa: E731
    lines = ["# Branch B on the fixture corpus", "",
             "| Page | Scenario | Expected | Branch B score | Label hint | Verdict | Evidence fired |",
             "| --- | --- | --- | --- | --- | --- | --- |"]
    for x in results:
        r = x["result"]
        ev = ", ".join(f"{e['id']} ({e['weight']})" for e in r["evidence"]) or "none"
        lines.append(f"| {x['page_id']} | {x['scenario']} | {'phishing-style' if x['label'] else 'legitimate-style'} "
                     f"| {r['risk_score']:.3f} | {r['label_hint']} | {x['verdict']} | {ev} |")
    lines += ["", f"TP={c['tp']} FP={c['fp']} TN={c['tn']} FN={c['fn']} "
                  f"precision={fmt(c['precision'])} recall={fmt(c['recall'])} "
                  "(\"suspicious\" counts as flagged; \"uncertain\" does not)"]
    notes = [f"- {x['page_id']}: {x['note']}" for x in results if x["note"]]
    if notes:
        lines += ["", "Notes:"] + notes
    return "\n".join(lines) + "\n"


def main(argv):
    if len(argv) < 2:
        sys.exit(__doc__)
    results = run(argv[1])
    c = summary(results)
    for x in results:
        r = x["result"]
        print(f"{x['page_id']:5} {r['risk_score']:.3f} {r['label_hint']:10} {x['verdict']:24} [{r['url_source']}]")
        print(f"      evidence: {', '.join(e['id'] for e in r['evidence']) or 'none'}")
        if x["note"]:
            print(f"      note: {x['note']}")
    fmt = lambda v: "n/a" if v is None else f"{v:.2f}"  # noqa: E731
    print(f"\n{len(results)} pages: TP={c['tp']} FP={c['fp']} TN={c['tn']} FN={c['fn']} "
          f"precision={fmt(c['precision'])} recall={fmt(c['recall'])}")
    if "--out" in argv:
        out = argv[argv.index("--out") + 1]
        os.makedirs(out, exist_ok=True)
        with open(os.path.join(out, "branch_b_corpus_report.md"), "w", encoding="utf-8") as f:
            f.write(report_md(results, c))
        for x in results:
            with open(os.path.join(out, f"{x['page_id']}.branch_b.json"), "w", encoding="utf-8") as f:
                json.dump(x["shared"], f, indent=1)
        print(f"wrote {out}/branch_b_corpus_report.md and {len(results)} shared-format files")


if __name__ == "__main__":
    main(sys.argv)
