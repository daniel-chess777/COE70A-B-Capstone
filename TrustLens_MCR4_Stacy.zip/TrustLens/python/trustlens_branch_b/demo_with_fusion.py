"""End-to-end check: Branch B -> shared format -> Derek's fusion (schema v0.1.0).

    python3 demo_with_fusion.py /path/to/trustlens_fusion                      # built-in cases
    python3 demo_with_fusion.py /path/to/trustlens_fusion --corpus <corpus>    # Daniel's P01-P04

The visual branch is sent as status "missing" (not connected yet), so fusion
works from the url / dom / text branches only.
"""
import sys

from url_html_text_branch import analyze
from shared_adapter import to_shared
from test_branch import LEGIT, PHISH, SSO

PAD = "<p>" + "Account services information and support content. " * 8 + "</p>"
CASES = [
    ("unit: legitimate PayPal login", "https://www.paypal.com/signin", LEGIT),
    ("unit: phishing-style PayPal", "http://paypal-secure-login.evil-site.xyz/login", PHISH),
    ("unit: SSO portal (Sign in with Microsoft)", "https://portal.acme.com/", SSO),
    ("unit: typosquat paypa1.com", "https://paypa1.com/signin", "<title>PayPal</title>" + PAD + "<form action='/x'><input type='password'></form>"),
    ("unit: evasive, clean domain, no brand", "https://secure-docs.example.net/view", PAD + "<form action='/s'><input type='password'></form>"),
]

STATUS = [
    ("Page capture", "not used", "implemented in the extension; this run reads the fixture HTML from files"),
    ("Branch B", "implemented", "url_html_text_branch.analyze() on each page"),
    ("Shared format", "implemented", "shared_adapter.to_shared(), schema v0.1.0, source=branch_b"),
    ("Visual branch", "unavailable", "sent to fusion as status 'missing' (not connected yet)"),
    ("Fusion", "implemented", "Derek's fuse(); output is a preliminary risk score, not calibrated"),
    ("Warning", "unavailable", "extension warning not connected to fusion yet"),
]

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    sys.path.insert(0, sys.argv[1])
    from fusion import fuse  # noqa: E402
    visual = {"schema_version": "0.1.0", "branch": "visual", "status": "missing", "missing_flags": ["vis.not_connected"]}
    # Status of each step in this demonstration (implemented / mocked / unavailable)
    print("Pipeline status for this run:")
    for step, status, note in STATUS:
        print(f"  {step:<20} {status:<12} {note}")
    cases = CASES
    if "--corpus" in sys.argv:
        import csv, os
        folder = sys.argv[sys.argv.index("--corpus") + 1]
        with open(os.path.join(folder, "test_corpus_inventory.csv"), newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        cases = []
        for row in rows:
            with open(os.path.join(folder, "test_pages", row["filename"]), encoding="utf-8") as f:
                cases.append((row["page_id"] + " " + row["scenario"], "http://127.0.0.1:8000/test_pages/" + row["filename"], f.read()))
    for name, url, html in cases:
        r = analyze(url, html)
        shared = to_shared(r, request_id=name)
        out = fuse({"schema_version": "0.1.0", "request_id": name, "branches": shared + [visual]})
        print(f"\n{name}\n  Branch B {r['risk_score']} ({r['label_hint']})  ->  fusion {out['decision'].upper()}"
              f"  p={out['p_fused']}  coverage={out['uncertainty']['coverage']}"
              + (f"  reasons={out['uncertainty']['reasons']}" if out['uncertainty']['reasons'] else ""))
        print("  p_phish sent:", {b["branch"]: b["p_phish"] for b in shared})
        for x in out["explanations"]:
            print(f"  - [{x['contribution']:+.2f}] {x['text']}")
