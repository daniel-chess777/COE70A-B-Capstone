"""
TrustLens - Visual Analysis Baseline
Student A: Daniel Avella Ordonez
MCR I / Weeks 4-5

Purpose:
- Screenshot preprocessing
- Candidate webpage-region extraction
- Credential-form / input-field detection
- Button detection
- Logo-region candidate detection
- Basic layout-region detection
- Optional logo template matching
- Structured evidence + confidence output
- Reproducible timing and evaluation support

This is a baseline prototype, not the final TrustLens detector.
It intentionally uses explainable computer-vision heuristics so each finding
can be inspected and passed to the multimodal fusion component.
"""

from __future__ import annotations
import argparse, json, time
from pathlib import Path
from typing import Any, Dict, List, Tuple

import cv2
import numpy as np


def clamp(v, lo=0.0, hi=1.0):
    return max(lo, min(hi, float(v)))


def preprocess(image: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Resize large screenshots while preserving aspect ratio and return
    grayscale + adaptive threshold image."""
    h, w = image.shape[:2]
    scale = min(1.0, 1400.0 / max(h, w))
    if scale < 1.0:
        image = cv2.resize(image, (int(w * scale), int(h * scale)),
                           interpolation=cv2.INTER_AREA)

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (5, 5), 0)
    threshold = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV, 31, 9
    )
    return image, threshold


def box_dict(x, y, w, h, confidence, label, evidence):
    return {
        "label": label,
        "bbox": [int(x), int(y), int(w), int(h)],
        "confidence": round(clamp(confidence), 3),
        "evidence": evidence,
    }


def detect_input_candidates(image: np.ndarray) -> List[Dict[str, Any]]:
    """Detect rectangular input-like regions using contour geometry."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

    H, W = gray.shape
    results = []
    for c in contours:
        x, y, w, h = cv2.boundingRect(c)
        area = w * h
        if area < 900 or w < 100 or h < 18:
            continue
        ratio = w / max(h, 1)
        rectangularity = area / max(cv2.contourArea(c), 1)
        if 3.0 <= ratio <= 18.0 and h <= 80 and w <= 0.85 * W:
            conf = 0.45
            if ratio >= 5:
                conf += 0.15
            if 0.95 <= rectangularity <= 1.8:
                conf += 0.15
            if y > 0.12 * H:
                conf += 0.05
            results.append(box_dict(
                x, y, w, h, conf, "input_candidate",
                ["wide_rectangular_region", "form-control_geometry"]
            ))
    return non_max_suppress(results, 0.35)


def detect_button_candidates(image: np.ndarray) -> List[Dict[str, Any]]:
    """Detect button-like rectangular regions."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 60, 170)
    contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)

    H, W = gray.shape
    results = []
    for c in contours:
        x, y, w, h = cv2.boundingRect(c)
        area = w * h
        if area < 500 or w < 55 or h < 20 or h > 100:
            continue
        ratio = w / max(h, 1)
        if 1.4 <= ratio <= 10 and w < 0.7 * W:
            conf = 0.42
            if 2 <= ratio <= 6:
                conf += 0.15
            if h <= 60:
                conf += 0.10
            results.append(box_dict(
                x, y, w, h, conf, "button_candidate",
                ["rectangular_control", "button_like_aspect_ratio"]
            ))
    return non_max_suppress(results, 0.4)


def detect_logo_region(image: np.ndarray) -> List[Dict[str, Any]]:
    """Baseline logo-region heuristic.

    It does not claim brand identity. It identifies candidate visual-brand
    regions, especially near the upper portion of a webpage.
    """
    H, W = image.shape[:2]
    top = image[:int(H * 0.35), :]
    gray = cv2.cvtColor(top, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    results = []
    for c in contours:
        x, y, w, h = cv2.boundingRect(c)
        area = w * h
        if area < 300 or w < 25 or h < 15 or w > 0.5 * W:
            continue
        if y > 0.75 * top.shape[0]:
            continue
        density = cv2.contourArea(c) / max(area, 1)
        conf = 0.38 + min(0.25, density * 0.25)
        results.append(box_dict(
            x, y, w, h, conf, "logo_region_candidate",
            ["upper_page_region", "compact_visual_region"]
        ))
    # Keep only a few candidates, largest first.
    results.sort(key=lambda r: r["bbox"][2] * r["bbox"][3], reverse=True)
    return results[:8]


def detect_layout_regions(image: np.ndarray) -> List[Dict[str, Any]]:
    """Detect large horizontal layout bands."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    H, W = gray.shape
    edges = cv2.Canny(gray, 50, 150)
    horizontal = cv2.morphologyEx(
        edges, cv2.MORPH_OPEN,
        cv2.getStructuringElement(cv2.MORPH_RECT, (max(25, W // 15), 3))
    )
    contours, _ = cv2.findContours(horizontal, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    results = []
    for c in contours:
        x, y, w, h = cv2.boundingRect(c)
        if w >= 0.45 * W and h <= 40:
            results.append(box_dict(
                x, y, w, h, 0.62, "layout_boundary",
                ["long_horizontal_boundary"]
            ))

    # Add deterministic coarse regions for downstream fusion.
    coarse = [
        ("header_region", 0, 0, W, int(H * 0.18), 0.55),
        ("main_content_region", 0, int(H * 0.18), W, int(H * 0.64), 0.55),
        ("footer_region", 0, int(H * 0.82), W, H - int(H * 0.82), 0.50),
    ]
    for label, x, y, w, h, conf in coarse:
        results.append(box_dict(
            x, y, w, h, conf, label,
            ["coarse_page_partition"]
        ))
    return results


def optional_logo_template_match(image: np.ndarray, template_path: str | None):
    if not template_path:
        return []
    p = Path(template_path)
    if not p.exists():
        return []
    template = cv2.imread(str(p), cv2.IMREAD_GRAYSCALE)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    if template is None or template.shape[0] > gray.shape[0] or template.shape[1] > gray.shape[1]:
        return []
    result = cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(result)
    th, tw = template.shape[:2]
    if max_val < 0.55:
        return []
    x, y = max_loc
    return [box_dict(
        x, y, tw, th, max_val, "logo_template_match",
        ["reference_template_match"]
    )]


def iou(a, b):
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    x1, y1 = max(ax, bx), max(ay, by)
    x2, y2 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    inter = max(0, x2-x1) * max(0, y2-y1)
    union = aw*ah + bw*bh - inter
    return inter / union if union else 0


def non_max_suppress(items, threshold):
    kept = []
    for item in sorted(items, key=lambda z: z["confidence"], reverse=True):
        if all(iou(item["bbox"], k["bbox"]) < threshold for k in kept):
            kept.append(item)
    return kept


def analyze(image_path: str, template_path: str | None = None):
    start = time.perf_counter()
    image = cv2.imread(image_path)
    if image is None:
        raise FileNotFoundError(image_path)

    processed, _ = preprocess(image)

    inputs = detect_input_candidates(processed)
    buttons = detect_button_candidates(processed)
    logos = detect_logo_region(processed)
    layouts = detect_layout_regions(processed)
    template_matches = optional_logo_template_match(processed, template_path)

    # Credential-form evidence: multiple input-like regions clustered together.
    credential_score = 0.15
    evidence = []
    if len(inputs) >= 2:
        credential_score += 0.45
        evidence.append("multiple_input_candidates")
    elif len(inputs) == 1:
        credential_score += 0.20
        evidence.append("input_candidate")

    if len(buttons) >= 1:
        credential_score += 0.15
        evidence.append("button_candidate")

    # A form-like cluster is more meaningful than a lone rectangle.
    if len(inputs) >= 2 and len(buttons) >= 1:
        credential_score += 0.20
        evidence.append("input_and_button_cluster")

    elapsed_ms = (time.perf_counter() - start) * 1000

    all_evidence = {
        "image": str(image_path),
        "image_size": {"width": int(processed.shape[1]), "height": int(processed.shape[0])},
        "processing_time_ms": round(elapsed_ms, 3),
        "detections": {
            "logo_candidates": logos,
            "logo_template_matches": template_matches,
            "input_candidates": inputs,
            "button_candidates": buttons,
            "layout_regions": layouts,
        },
        "credential_form_evidence": {
            "score": round(clamp(credential_score), 3),
            "confidence": round(clamp(credential_score), 3),
            "evidence": evidence,
        },
        "notes": [
            "This baseline uses explainable image-processing heuristics.",
            "Logo-region detection identifies candidate regions; it does not establish brand identity.",
            "Template matching is optional and requires a legitimate reference image.",
            "Scores are baseline detector confidences, not calibrated phishing probabilities."
        ]
    }
    return all_evidence, processed


def draw_evidence(image, result):
    canvas = image.copy()
    labels = {
        "logo_candidates": (255, 120, 0),
        "logo_template_matches": (255, 0, 255),
        "input_candidates": (0, 180, 0),
        "button_candidates": (0, 0, 220),
        "layout_regions": (180, 180, 0),
    }
    for group, detections in result["detections"].items():
        for d in detections:
            x, y, w, h = d["bbox"]
            color = labels.get(group, (180, 180, 180))
            cv2.rectangle(canvas, (x, y), (x+w, y+h), color, 2)
            text = f'{d["label"]} {d["confidence"]:.2f}'
            cv2.putText(canvas, text, (x, max(15, y-4)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 1, cv2.LINE_AA)
    return canvas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("image")
    ap.add_argument("--template", default=None)
    ap.add_argument("--json-out", default="visual_evidence.json")
    ap.add_argument("--annotated-out", default="visual_evidence.png")
    args = ap.parse_args()

    result, processed = analyze(args.image, args.template)
    Path(args.json_out).write_text(json.dumps(result, indent=2), encoding="utf-8")
    annotated = draw_evidence(processed, result)
    cv2.imwrite(args.annotated_out, annotated)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
