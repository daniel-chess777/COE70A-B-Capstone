# MCR I — Student A Visual Analysis Baseline Report

## Scope

This artifact implements the initial TrustLens visual-analysis baseline for Daniel
Avella Ordonez (Student A). It targets screenshot preprocessing, region extraction,
logo-region candidates, credential/input-form candidates, button candidates,
coarse layout regions, structured evidence, confidence values, and timing.

## Controlled demonstration

Two locally generated screenshots are included:

- `test_corpus/legitimate_login.png`
- `test_corpus/reconstructed_phishing.png`

The samples are intentionally controlled and do not use active malicious websites
or real credentials.

## Results

See `evaluation.csv` and the annotated images in `outputs/`.

The measured processing time is recorded automatically by the detector. Detection
counts are included for input candidates, button candidates, and logo-region
candidates.

## Limitations

- The logo detector identifies candidate visual regions; it does not prove brand identity.
- The current form/button detector is geometry-based and can produce false positives.
- The current layout detector uses coarse partitions and visual boundaries.
- Template matching is optional and should be evaluated using a curated legitimate
  reference set.
- The two demonstration pages are synthetic; they are not sufficient to establish
  general accuracy.

## Next step

Run the same pipeline on the team's actual controlled offline corpus and manually
label true/false detections. Record localization performance, false matches, and
processing latency before integrating the visual evidence into the multimodal fusion
component.
