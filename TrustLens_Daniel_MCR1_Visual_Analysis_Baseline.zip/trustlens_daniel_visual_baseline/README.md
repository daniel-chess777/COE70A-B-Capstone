# TrustLens — Daniel's Visual Analysis Baseline

**Student:** Daniel Avella Ordonez (Student A)  
**Project:** YA07 TrustLens  
**Milestone:** MCR I — Weeks 4 & 5

## Deliverable coverage

This baseline directly targets the MCR I Student A tasks:

1. Screenshot preprocessing.
2. Candidate webpage-region extraction.
3. Initial detection of logo regions.
4. Initial detection of credential/input-form regions.
5. Initial detection of button-like controls.
6. Coarse webpage layout-region detection.
7. Optional legitimate-logo template matching.
8. Structured evidence and confidence values for multimodal fusion.
9. Processing-time measurement.
10. Annotated visual output for inspection.

The MCR specifies that Student A should establish an initial visual-analysis baseline and evaluate logo, form, and layout detection using the initial test corpus, recording errors, false matches, and processing time.

## Run

```bash
pip install -r requirements.txt

python src/visual_analysis.py test_corpus/legitimate_login.png   --json-out outputs/legitimate_evidence.json   --annotated-out outputs/legitimate_annotated.png

python src/visual_analysis.py test_corpus/reconstructed_phishing.png   --json-out outputs/phishing_evidence.json   --annotated-out outputs/phishing_annotated.png
```

Optional logo reference:

```bash
python src/visual_analysis.py test_corpus/legitimate_login.png   --template references/logo_reference.png   --json-out outputs/legitimate_evidence.json   --annotated-out outputs/legitimate_annotated.png
```

## Important interpretation

This is a **baseline prototype**, not a finished phishing detector. The visual detector produces evidence that the later TrustLens fusion layer can consume. It does not independently claim that a webpage is malicious.

Logo-region detection is intentionally described as *candidate visual-brand region detection*. Brand identity requires a legitimate reference set and should be evaluated separately.

## Evidence produced

Each analysis produces:

- bounding boxes
- detector labels
- confidence values
- processing time
- input/form evidence score
- reasons supporting each detection

This makes the output suitable for the multimodal fusion interface described in the project plan.

## What to show Yasmin

Show:

1. `src/visual_analysis.py`
2. the two annotated screenshots in `outputs/`
3. the JSON evidence files
4. `evaluation.csv`
5. the processing-time values
6. the known limitations and next steps

Do not present the baseline as a completed final detector. Present it as the initial Week 4–5 visual-analysis prototype/baseline.
