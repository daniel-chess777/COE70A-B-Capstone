# Branch B on the fixture corpus

| Page | Scenario | Expected | Branch B score | Label hint | Verdict | Evidence fired |
| --- | --- | --- | --- | --- | --- | --- |
| P01 | legitimate_style | legitimate-style | 0.239 | safe | correct | text.credential_request (0.11), html.password_form (0.1), url.sensitive_words (0.05) |
| P02 | suspicious_style | phishing-style | 0.391 | uncertain | missed (uncertain) | text.urgency (0.2), text.credential_request (0.11), html.password_form (0.1), url.sensitive_words (0.05) |
| P03 | legitimate_alternative_layout | legitimate-style | 0.000 | safe | correct | none |
| P04 | incomplete_visual_evidence | legitimate-style | 0.050 | safe | correct | url.sensitive_words (0.05) |

TP=0 FP=0 TN=3 FN=1 precision=n/a recall=0.00 ("suspicious" counts as flagged; "uncertain" does not)

## How these results were produced

- Corpus: Daniel's `TrustLens_MCR2_Test_Corpus` (P01–P04), run on 2026-11-04.
- Command: `python3 python/trustlens_branch_b/run_corpus.py <corpus folder> --out results`
- Each page is analyzed as if served from `127.0.0.1`; Branch B reads the page's `data-intended-url` attribute (`url_source: fixture_meta`).
- `P0x.branch_b.json` is each page's Branch B output in the shared evidence format (schema v0.1.0, `source: branch_b`).
- `fusion_on_corpus.txt` is the same pages sent through Derek's `fuse()` with the visual branch unavailable (`python3 python/trustlens_branch_b/demo_with_fusion.py <trustlens_fusion> --corpus <corpus folder>`).

## Reading the results

- **Correct (P01, P03, P04).** No legitimate-style page was flagged, so there are no false positives.
- **Missed (P02).** P02 scores 0.391 (uncertain), not suspicious. Its intended URL is on the brand's own domain, so the only phishing sign is the altered logo. Branch B picks up its urgency language and credential request, but these are weak signals by design. With the visual branch unavailable, fusion also allows P02. This is the missing-visual-evidence case: P02 should move to warn once Daniel's visual output is connected.
- **Open: real PayPal false positive.** Not investigated yet; waiting for the saved scan (`scan.json`, `page.html.txt`) so the fired rules can be checked.
