import { collectPage } from "./lib/collect.js";
import { scoreScan } from "./lib/heuristics.js";
import { analyze } from "./lib/branch_b.js";

const $ = (id) => document.getElementById(id);
let tab;

function li(text, weight) {
  const el = document.createElement("li");
  el.textContent = text;
  if (weight !== undefined) {
    const w = document.createElement("span");
    w.className = "w";
    w.textContent = ` (${weight})`;
    el.append(w);
  }
  return el;
}

function pill(el, value) {
  el.textContent = value;
  el.className = `pill ${value}`;
}

function render(scan) {
  const h = scan.heuristics;
  pill($("protoLevel"), h.level);
  $("protoScore").textContent = h.score;
  $("protoFlags").replaceChildren(...(h.flags.length ? h.flags.map((f) => li(f.reason, `+${f.points}`)) : [li("No indicators")]));

  const b = scan.branchB;
  pill($("bLabel"), b.label_hint);
  $("bScore").textContent = b.risk_score.toFixed(3);
  $("bConf").textContent = b.confidence;
  $("bMissing").textContent = b.missing.join(", ") || "none";
  $("bEvidence").replaceChildren(...(b.evidence.length ? b.evidence.map((e) => li(e.description, e.weight)) : [li("No evidence")]));
  $("results").hidden = false;
}

function download(blobOrUrl, filename) {
  const url = typeof blobOrUrl === "string" ? blobOrUrl : URL.createObjectURL(blobOrUrl);
  return chrome.downloads.download({ url, filename, conflictAction: "uniquify", saveAs: false });
}

async function scan() {
  $("scan").disabled = true;
  $("status").textContent = "Scanning…";
  try {
    const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: collectPage });
    const scannedAt = new Date().toISOString();
    const screenshot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" }).catch(() => null);

    const scan = { scannedAt, tabTitle: tab.title, ...result.scan };
    scan.heuristics = scoreScan(scan);
    scan.branchB = analyze(scan.url, result.html);
    render(scan);

    if ($("save").checked) {
      const host = new URL(scan.url).hostname || "page";
      const dir = `PhishScans/${host}_${scannedAt.replace(/[:.]/g, "-")}`;
      await download(new Blob([JSON.stringify(scan, null, 2)], { type: "application/json" }), `${dir}/scan.json`);
      // .txt so the saved page can't be opened and run by accident
      await download(new Blob([result.html], { type: "text/plain" }), `${dir}/page.html.txt`);
      if (screenshot) await download(screenshot, `${dir}/screenshot.png`);
      $("status").textContent = `Saved to Downloads/${dir}/`;
    } else {
      $("status").textContent = "";
    }
  } catch (err) {
    $("status").textContent = `Scan failed: ${err.message}`;
  } finally {
    $("scan").disabled = false;
  }
}

(async () => {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  $("url").textContent = tab?.url || "(no URL)";
  const scannable = /^https?:/.test(tab?.url || "");
  $("scan").disabled = !scannable;
  if (!scannable) $("status").textContent = "Only http(s) pages can be scanned.";
})();

$("scan").addEventListener("click", scan);
$("selftest").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: chrome.runtime.getURL("selftest/selftest.html") });
});
