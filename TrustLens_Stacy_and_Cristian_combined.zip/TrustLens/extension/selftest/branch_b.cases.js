// Branch B unit tests (Stacy Nwankwo), ported from
// python/trustlens_branch_b/test_branch.py. The same cases run:
//   - inside the extension:  selftest/selftest.html  (popup -> "Run self-tests")
//   - in Node:               npm test
import { analyze, visibleText, registeredDomain } from "../lib/branch_b.js";
import { LEGIT, PHISH, SSO } from "./fixtures.js";

const ids = (r) => new Set(r.evidence.map((e) => e.id));

export const cases = [
  ["legit login is safe", (t) => {
    const r = analyze("https://www.paypal.com/signin", LEGIT);
    t.less(r.risk_score, 0.3); t.equal(r.label_hint, "safe");
  }],
  ["phish is suspicious", (t) => {
    const r = analyze("http://paypal-secure-login.evil-site.xyz/login", PHISH);
    t.greaterEqual(r.risk_score, 0.9);
    t.subset(["html.cross_domain_form", "html.mismatched_link", "text.brand_claim_mismatch",
      "url.brand_in_domain", "text.urgency"], ids(r));
  }],
  ["SSO page not flagged as brand claim", (t) => {
    const r = analyze("https://portal.acme.com/", SSO);
    t.notIncludes(ids(r), "text.brand_claim_mismatch"); t.equal(r.label_hint, "safe");
  }],
  ["IP host, @ symbol, shortener", (t) => {
    t.includes(ids(analyze("http://192.168.1.5/login")), "url.ip_host");
    t.includes(ids(analyze("https://paypal.com@evil.com/")), "url.at_symbol");
    t.includes(ids(analyze("https://bit.ly/3abc")), "url.shortener");
  }],
  ["typosquat and subdomain brand", (t) => {
    t.includes(ids(analyze("https://paypa1.com/")), "url.typosquat");
    t.includes(ids(analyze("https://paypal.com.evil.net/")), "url.brand_in_domain");
    t.deepEqual(analyze("https://www.paypal.com/").evidence.filter((e) => e.id.startsWith("url.brand")), []);
  }],
  ["IDN reported as safe ASCII", (t) => {
    const r = analyze("https://pаypal.com/"); // Cyrillic 'а'
    const e = r.evidence.find((x) => x.id === "url.idn_host");
    t.ok(e, "url.idn_host missing");
    t.ok(/^[\x00-\x7f]*$/.test(e.detail.ascii), "detail.ascii is not ASCII");
  }],
  ["embedded redirect", (t) => {
    t.includes(ids(analyze("https://x.com/r?u=http%3A%2F%2Fevil.com")), "url.embedded_redirect");
  }],
  ["hidden content not visible", (t) => {
    const h = "<p>Hello</p><div style='display:none'>SECRET</div><script>var x=1</script><span hidden>no</span>";
    t.equal(visibleText(h), "Hello");
  }],
  ["hidden form and iframe", (t) => {
    const h = "<form style='display:none' action='/a'><input type='password'></form><iframe src='http://evil.com/x' width='0'></iframe>";
    t.subset(["html.hidden_form", "html.hidden_iframe"], ids(analyze("https://a.com/", h)));
  }],
  ["tracking iframes without password stay weak", (t) => {
    // adidas.ca false alarm: ad/analytics iframes on a shop page with no password field
    const frames = "<iframe src='https://insight.adsrvr.org/track' style='display:none'></iframe>"
      + "<iframe src='https://1.fls.doubleclick.net/a' width='0'></iframe>";
    const shop = "<p>" + "New arrivals, shoes and clothing for every sport. Sign in for offers. ".repeat(6) + "</p>";
    const r = analyze("https://www.shop.ca/en/lifestyle", shop + frames);
    const e = r.evidence.filter((x) => x.id === "html.hidden_iframe");
    t.equal(e.length, 1); t.deepEqual(e[0].detail.domains, ["adsrvr.org", "doubleclick.net"]);
    t.equal(r.label_hint, "safe");
    const login = analyze("https://www.shop.ca/login", shop + frames + "<form><input type='password'></form>");
    t.deepEqual(login.evidence.filter((x) => x.id === "html.hidden_iframe").map((x) => x.weight), [0.3]);
  }],
  ["URL only lowers confidence", (t) => {
    const r = analyze("https://example.com/");
    t.includes(r.missing, "html"); t.lessEqual(r.confidence, 0.4);
  }],
  ["limited text flagged", (t) => {
    t.includes(analyze("https://a.com/", "<form><input type='password'></form>").missing, "limited_visible_text");
  }],
  ["registered domain", (t) => {
    t.equal(registeredDomain("a.b.example.co.uk"), "example.co.uk");
    t.equal(registeredDomain("www.paypal.com"), "paypal.com");
  }],
  ["redirects", (t) => {
    const r = analyze("https://a.com/", "<meta http-equiv='refresh' content='0;url=http://b.com'><script>window.location='http://b.com'</script>");
    t.subset(["html.meta_refresh", "html.js_redirect"], ids(r));
  }],
];
