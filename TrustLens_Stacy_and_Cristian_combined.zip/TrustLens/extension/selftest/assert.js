// Tiny assertion helpers shared by the browser self-test page and Node's test runner.
export class AssertionError extends Error {}

const show = (v) => JSON.stringify(v instanceof Set ? [...v] : v);
function fail(msg) { throw new AssertionError(msg); }

export const assert = {
  ok(v, msg = "expected truthy value") { if (!v) fail(msg); },
  equal(a, b, msg) { if (a !== b) fail(msg || `${show(a)} !== ${show(b)}`); },
  deepEqual(a, b, msg) { if (show(a) !== show(b)) fail(msg || `${show(a)} != ${show(b)}`); },
  less(a, b, msg) { if (!(a < b)) fail(msg || `${a} is not < ${b}`); },
  lessEqual(a, b, msg) { if (!(a <= b)) fail(msg || `${a} is not <= ${b}`); },
  greaterEqual(a, b, msg) { if (!(a >= b)) fail(msg || `${a} is not >= ${b}`); },
  includes(collection, item, msg) {
    const has = collection instanceof Set ? collection.has(item) : collection.includes(item);
    if (!has) fail(msg || `${show(item)} not in ${show(collection)}`);
  },
  notIncludes(collection, item, msg) {
    const has = collection instanceof Set ? collection.has(item) : collection.includes(item);
    if (has) fail(msg || `${show(item)} unexpectedly in ${show(collection)}`);
  },
  subset(items, collection, msg) {
    const missing = [...items].filter((i) => !(collection instanceof Set ? collection.has(i) : collection.includes(i)));
    if (missing.length) fail(msg || `missing ${show(missing)} from ${show(collection)}`);
  },
};
