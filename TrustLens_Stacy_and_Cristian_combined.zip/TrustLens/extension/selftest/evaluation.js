// Week-7 style evaluation: precision/recall/FPR + failure listing on a labelled
// corpus. Port of python/trustlens_branch_b/evaluate.py; label 1 = phishing-style,
// 0 = legitimate. Shown on the self-test page and runnable via `npm run evaluate`.
import { analyze } from "../lib/branch_b.js";
import { LEGIT, PHISH, SSO, PAD } from "./fixtures.js";

export const SAMPLES = [
  ["paypal legit", "https://www.paypal.com/signin", LEGIT, 0],
  ["acme sso", "https://portal.acme.com/", SSO, 0],
  ["plain blog", "https://blog.example.org/post", "<h1>Hi</h1>" + PAD, 0],
  ["bank legit login", "https://www.rbcroyalbank.com/login", "<title>RBC Sign in</title>" + PAD + "<form action='/auth'><input type='password'></form>", 0],
  ["phish classic", "http://paypal-secure-login.evil-site.xyz/login", PHISH, 1],
  ["phish ip host", "http://203.0.113.9/rbc/login", "<title>RBC Sign in</title>" + PAD + "<form action='post.php'><input type='password'></form>", 1],
  ["phish typosquat", "https://paypa1.com/signin", "<title>PayPal</title>" + PAD + "<form action='/x'><input type='password'></form>", 1],
  ["phish shortened + hidden form", "https://bit.ly/3xYz", "<form style='display:none' action='http://a.top/c'><input type='password'></form>", 1],
  ["evasive: clean domain, no brand text", "https://secure-docs.example.net/view", PAD + "<form action='/s'><input type='password'></form>", 1],
];

export function evaluate(samples = SAMPLES) {
  let tp = 0, fp = 0, tn = 0, fn = 0;
  const misses = [];
  for (const [name, url, html, y] of samples) {
    const r = analyze(url, html);
    const pred = r.label_hint === "suspicious" ? 1 : 0;
    if (pred && y) tp++; else if (pred && !y) fp++; else if (!pred && !y) tn++; else fn++;
    if (pred !== y) misses.push({ name, risk_score: r.risk_score, label_hint: r.label_hint, evidence: r.evidence.map((e) => e.id) });
  }
  const precision = tp + fp ? tp / (tp + fp) : 0;
  const recall = tp + fn ? tp / (tp + fn) : 0;
  const fpr = fp + tn ? fp / (fp + tn) : 0;
  return { tp, fp, tn, fn, precision, recall, fpr, misses };
}

export function formatEvaluation(m) {
  const lines = [`TP=${m.tp} FP=${m.fp} TN=${m.tn} FN=${m.fn} precision=${m.precision.toFixed(2)} recall=${m.recall.toFixed(2)} FPR=${m.fpr.toFixed(2)}`];
  for (const b of m.misses) lines.push(`MISS: ${b.name} ${b.risk_score} ${b.label_hint} [${b.evidence.join(", ")}]`);
  return lines.join("\n");
}
