// Runs Branch B's unit tests and evaluation inside the extension, using the
// exact analyzer code the popup uses.
import { cases } from "./branch_b.cases.js";
import { assert } from "./assert.js";
import { evaluate, formatEvaluation } from "./evaluation.js";

const list = document.getElementById("cases");
let passed = 0;
for (const [name, fn] of cases) {
  const el = document.createElement("li");
  try {
    fn(assert);
    passed++;
    el.className = "ok";
    el.textContent = `✓ ${name}`;
  } catch (err) {
    el.className = "bad";
    el.textContent = `✗ ${name}: ${err.message}`;
  }
  list.append(el);
}
const summary = document.getElementById("summary");
summary.textContent = `${passed}/${cases.length} tests passed`;
summary.className = passed === cases.length ? "ok" : "bad";
document.getElementById("eval").textContent = formatEvaluation(evaluate());
