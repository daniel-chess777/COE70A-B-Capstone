# COE70A-B-Capstone — TrustLens

TrustLens is a phishing-triage Chrome extension. This repo combines:

- **Cristian's extension prototype (MCR1):** popup, "Scan this page", saved scan files (`scan.json`, `page.html.txt`, `screenshot.png`) and a low/medium/high triage score. The write-up and sample scans are in `deliverables/cristian_mcr1/`.
- **Stacy's Branch B (MCR1):** URL, HTML/DOM and visible-text analysis with unit tests and an evaluation corpus. The original Python is in `python/trustlens_branch_b/`. A JavaScript port runs inside the extension.

## Layout

```
extension/                  Load this folder in chrome://extensions ("Load unpacked")
  manifest.json             MV3; permissions: activeTab, scripting, downloads
  popup.html/.css/.js       Popup: scan, show both results, save files
  lib/collect.js            Runs in the page and gathers the scan.json indicators + HTML
  lib/heuristics.js         Prototype points score -> low / medium / high
  lib/branch_b.js           Branch B analyzer (JS port of url_html_text_branch.py)
  lib/html_parser.js        Tokenizer matching Python's html.parser
  lib/pyport.js             difflib ratio, urlparse, unquote, parse_qs ports
  selftest/                 Branch B tests + evaluation, runnable inside the extension
python/trustlens_branch_b/  Stacy's original Python module, tests, evaluate.py
tests/                      Node test runner (unit, parity, heuristics)
deliverables/cristian_mcr1/ Prototype write-up PDF + saved nike.com / adidas.ca scans
```

## Using the extension

1. Open `chrome://extensions`, turn on Developer mode, then click **Load unpacked** and pick the `extension/` folder.
2. On any http(s) page, click the TrustLens icon and then **Scan this page**. The popup shows:
   - **Prototype triage**: points, level and reasons.
   - **Branch B**: `risk_score`, `label_hint`, `confidence`, `missing` and the weighted evidence list.
3. With "Save scan files" ticked, the files go to `Downloads/PhishScans/<host>_<timestamp>/`. `scan.json` now also holds `heuristics` and `branchB`, the shared branch-schema output for fusion.
4. Click **Run self-tests** in the popup to run Branch B's unit tests and evaluation corpus inside Chrome. These use the same analyzer code the popup uses.

## Tests

```
npm test          # JS: Branch B unit tests, Python<->JS parity, prototype heuristics
npm run test:py   # Python: Stacy's original unittest suite
npm run evaluate  # Branch B precision / recall / FPR (JS port of evaluate.py)
```

- `tests/branch_b.test.js` runs the same cases as the in-extension self-test page (`extension/selftest/branch_b.cases.js`). These are a 1:1 port of `test_branch.py`.
- `tests/parity.test.js` checks that the JS analyzer gives the same evidence, weights and scores as the Python one. It covers 29 cases, including Cristian's real nike.com and adidas.ca pages. **If you change the Python analyzer, make the same change in `extension/lib/branch_b.js`, then run `npm run parity:update`**. The test fails if the two drift apart.
- `tests/heuristics.test.js` checks that the prototype score reproduces the scores stored in Cristian's saved scans.

No dependencies: Node 18+ and Python 3 standard library only.
