// Node equivalent of `python evaluate.py` for the JavaScript port of Branch B.
import { evaluate, formatEvaluation } from "../extension/selftest/evaluation.js";

console.log(formatEvaluation(evaluate()));
