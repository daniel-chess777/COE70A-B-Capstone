"""Week-7 style evaluation harness: precision/recall/FPR + failure listing on a labelled corpus.
Corpus = list of (name, url, html, label) with label 1 = phishing-style, 0 = legitimate.
Replace SAMPLES with the team's offline corpus loader (e.g. folder of .html + labels.csv)."""
from url_html_text_branch import analyze
from test_branch import LEGIT, PHISH, SSO

PAD = "<p>" + "Account services information and support content. " * 8 + "</p>"
SAMPLES = [
 ("paypal legit", "https://www.paypal.com/signin", LEGIT, 0),
 ("acme sso", "https://portal.acme.com/", SSO, 0),
 ("plain blog", "https://blog.example.org/post", "<h1>Hi</h1>" + PAD, 0),
 ("bank legit login", "https://www.rbcroyalbank.com/login", "<title>RBC Sign in</title>" + PAD + "<form action='/auth'><input type='password'></form>", 0),
 ("phish classic", "http://paypal-secure-login.evil-site.xyz/login", PHISH, 1),
 ("phish ip host", "http://203.0.113.9/rbc/login", "<title>RBC Sign in</title>" + PAD + "<form action='post.php'><input type='password'></form>", 1),
 ("phish typosquat", "https://paypa1.com/signin", "<title>PayPal</title>" + PAD + "<form action='/x'><input type='password'></form>", 1),
 ("phish shortened + hidden form", "https://bit.ly/3xYz", "<form style='display:none' action='http://a.top/c'><input type='password'></form>", 1),
 ("evasive: clean domain, no brand text", "https://secure-docs.example.net/view", PAD + "<form action='/s'><input type='password'></form>", 1),
]
tp = fp = tn = fn = 0; bad = []
for n, u, h, y in SAMPLES:
    r = analyze(u, h); pred = int(r["label_hint"] == "suspicious")
    tp += pred and y; fp += pred and not y; tn += (not pred) and not y; fn += (not pred) and y
    if pred != y: bad.append((n, r["risk_score"], r["label_hint"], [e["id"] for e in r["evidence"]]))
p = tp / (tp + fp) if tp + fp else 0; rc = tp / (tp + fn) if tp + fn else 0
print(f"TP={tp} FP={fp} TN={tn} FN={fn} precision={p:.2f} recall={rc:.2f} FPR={fp/(fp+tn):.2f}")
for b in bad: print("MISS:", b)
