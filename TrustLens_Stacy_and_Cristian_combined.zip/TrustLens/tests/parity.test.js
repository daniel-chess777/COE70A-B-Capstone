// The extension's JavaScript Branch B must agree with Stacy's Python Branch B.
// Expected outputs come from tests/gen_parity_fixtures.py (Python), including
// Cristian's real captured pages (deliverables/cristian_mcr1/TrustlensProtoScans).
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { analyze } from "../extension/lib/branch_b.js";

const root = new URL("../", import.meta.url);
const fixtures = JSON.parse(readFileSync(new URL("tests/fixtures/branch_b_parity.json", root), "utf8"));

const close = (a, b) => Math.abs(a - b) < 1e-9 + 1e-3;

for (const fx of fixtures) {
  test(`parity: ${fx.name}`, () => {
    const html = fx.htmlFile ? readFileSync(new URL(fx.htmlFile, root), "utf8") : fx.html;
    const got = analyze(fx.url, html);
    const exp = fx.expected;
    assert.equal(got.branch, exp.branch);
    assert.equal(got.label_hint, exp.label_hint);
    assert.deepEqual(got.missing, exp.missing);
    assert.ok(close(got.risk_score, exp.risk_score), `risk_score ${got.risk_score} vs ${exp.risk_score}`);
    assert.ok(close(got.confidence, exp.confidence), `confidence ${got.confidence} vs ${exp.confidence}`);
    assert.deepEqual(
      got.evidence.map((e) => [e.id, e.modality, e.weight, e.description, e.detail]),
      exp.evidence.map((e) => [e.id, e.modality, e.weight, e.description, e.detail]),
    );
  });
}
