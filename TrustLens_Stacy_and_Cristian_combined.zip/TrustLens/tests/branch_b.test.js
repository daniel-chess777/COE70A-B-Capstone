// Runs the same Branch B cases the extension's self-test page runs.
import { test } from "node:test";
import { cases } from "../extension/selftest/branch_b.cases.js";
import { assert } from "../extension/selftest/assert.js";
import { evaluate } from "../extension/selftest/evaluation.js";

for (const [name, fn] of cases) test(`branch B: ${name}`, () => fn(assert));

test("branch B: evaluation matches python evaluate.py", () => {
  const m = evaluate();
  assert.deepEqual([m.tp, m.fp, m.tn, m.fn], [4, 0, 4, 1]);
  assert.deepEqual(m.misses.map((x) => x.name), ["evasive: clean domain, no brand text"]);
});
