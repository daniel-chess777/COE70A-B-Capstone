// The prototype score must reproduce the scores stored in Cristian's saved scans.
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { scoreScan } from "../extension/lib/heuristics.js";

const dir = new URL("../deliverables/cristian_mcr1/TrustlensProtoScans/", import.meta.url);

for (const name of readdirSync(dir)) {
  test(`heuristics reproduce saved scan: ${name}`, () => {
    const scan = JSON.parse(readFileSync(new URL(`${name}/scan.json`, dir), "utf8"));
    const got = scoreScan(scan);
    assert.equal(got.score, scan.heuristics.score);
    assert.equal(got.level, scan.heuristics.level);
    assert.deepEqual(got.flags, scan.heuristics.flags);
  });
}

test("heuristics: phishing-style indicators reach high", () => {
  const got = scoreScan({
    urlFeatures: { protocol: "http:", isIPHost: true, urlLength: 30, subdomainCount: 0, hyphenCount: 0 },
    forms: [{ action: "http://collect.evil.xyz/p.php", externalAction: true, hasPassword: true }],
    links: { total: 4, empty: 0, mismatched: [{ text: "www.paypal.com", href: "http://evil.xyz" }] },
    keywordHits: ["account suspended", "password"], passwordFields: 1,
  });
  assert.equal(got.level, "high");
  assert.ok(got.flags.some((f) => f.reason === "Password form submits to a different domain"));
});
