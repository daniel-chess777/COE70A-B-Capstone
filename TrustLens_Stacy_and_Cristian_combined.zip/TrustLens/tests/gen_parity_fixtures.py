"""Regenerate tests/fixtures/branch_b_parity.json from the Python Branch B.

The JavaScript port in extension/lib/branch_b.js must give the same output as
python/trustlens_branch_b/url_html_text_branch.py; tests/parity.test.js checks
it against this file. Re-run after changing the Python analyzer:

    python3 tests/gen_parity_fixtures.py
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "python", "trustlens_branch_b"))

from url_html_text_branch import analyze  # noqa: E402
from test_branch import LEGIT, PHISH, SSO  # noqa: E402

PAD = "<p>" + "Account services information and support content. " * 8 + "</p>"
SCANS = "deliverables/cristian_mcr1/TrustlensProtoScans"

CASES = [
    # Unit-test and evaluation corpus pages
    ("paypal legit", "https://www.paypal.com/signin", LEGIT),
    ("phish classic", "http://paypal-secure-login.evil-site.xyz/login", PHISH),
    ("acme sso", "https://portal.acme.com/", SSO),
    ("plain blog", "https://blog.example.org/post", "<h1>Hi</h1>" + PAD),
    ("bank legit login", "https://www.rbcroyalbank.com/login", "<title>RBC Sign in</title>" + PAD + "<form action='/auth'><input type='password'></form>"),
    ("phish ip host", "http://203.0.113.9/rbc/login", "<title>RBC Sign in</title>" + PAD + "<form action='post.php'><input type='password'></form>"),
    ("phish typosquat", "https://paypa1.com/signin", "<title>PayPal</title>" + PAD + "<form action='/x'><input type='password'></form>"),
    ("phish shortened + hidden form", "https://bit.ly/3xYz", "<form style='display:none' action='http://a.top/c'><input type='password'></form>"),
    ("evasive", "https://secure-docs.example.net/view", PAD + "<form action='/s'><input type='password'></form>"),
    # URL-only
    ("url ip", "http://192.168.1.5/login", None),
    ("url at", "https://paypal.com@evil.com/", None),
    ("url idn", "https://pаypal.com/", None),
    ("url redirect", "https://x.com/r?u=http%3A%2F%2Fevil.com", None),
    ("url many parts", "http://login.secure.account.verify.paypal-update-now-x.top/a;b?c=1#f", None),
    ("url netflix typo", "https://netfl1x.com/", None),
    ("url rn->m", "https://arnazon.co.uk/x", None),
    ("url encoded", "https://ex.com/%41%42%43%44%45%46", None),
    ("url ipv6", "http://[::1]:8080/x", None),
    ("url empty", "", None),
    # Parser edge cases
    ("parser entities", "https://a.com/", "<title>PayPal &amp; you</title><p>Tom &amp; Jerry &copy 2026 &#8211; x&nbsp;y &bogus;</p>" + PAD),
    ("parser raw text", "https://a.com/", "<title><b>t</b></title><script>if(a<b){document.location='x'}</script><style>p{}</style><textarea><i>q</i></textarea>" + PAD),
    ("parser comments", "https://a.com/", "a<!-- <a href='http://x.com'>www.y.com</a> -->b<!DOCTYPE html><?xml x?><div/>c" + PAD),
    ("parser attrs", "https://a.com/", "<A HREF=\"http://evil.com/x\" Hidden>www.paypal.com</A><a href=http://e2.com/ >www.td.com</a><a href='#'>x</a><a>y</a><iframe src=http://z.com height=1></iframe>"),
    ("parser hidden styles", "https://a.com/", "<div style='opacity: 0'><a href='http://q.com'>a</a><a href='http://q.com'>b</a><a href='http://q.com'>c</a></div><div style='position:absolute; left:-9999px'>secret password</div><p style='opacity:0.5'>shown</p>"),
    ("parser forms", "https://a.com/", "<form action='javascript:void(0)'><input type=password></form><form action='http://other.org/p'><input type='PASSWORD'></form><form action='https://a.com/ok'><input></form>"),
    ("parser unclosed", "https://a.com/", "<p>unterminated <a href='http://b.com'>www.c.com"),
    ("brand mentions", "https://login.example.com/", "<p>Microsoft account. Microsoft says urgent: act now, final notice, expires today.</p><form><input type='password'></form>"),
]


def scan_cases():
    base = os.path.join(ROOT, SCANS)
    for d in sorted(os.listdir(base)):
        with open(os.path.join(base, d, "scan.json"), encoding="utf-8") as f:
            url = json.load(f)["url"]
        yield (d, url, SCANS + "/" + d + "/page.html.txt")


def main():
    out = []
    for name, url, html in CASES:
        out.append({"name": name, "url": url, "html": html, "expected": analyze(url, html)})
    for name, url, rel in scan_cases():
        with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
            html = f.read()
        out.append({"name": "scan " + name, "url": url, "htmlFile": rel, "expected": analyze(url, html)})
    path = os.path.join(ROOT, "tests", "fixtures", "branch_b_parity.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1, ensure_ascii=False)
        f.write("\n")
    print(f"wrote {len(out)} cases to {os.path.relpath(path, ROOT)}")


if __name__ == "__main__":
    main()
