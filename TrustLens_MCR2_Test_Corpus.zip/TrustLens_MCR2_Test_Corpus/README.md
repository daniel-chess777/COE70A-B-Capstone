# TrustLens — MCR II Test Corpus

## Purpose
This corpus provides four controlled local HTML fixtures for testing TrustLens phishing-detection modules. It is intended for initial functional testing, not production deployment or a validated security evaluation.

## Test pages

| Page ID | Fixture | Intended scenario |
|---|---|---|
| P01 | Legitimate match | Claimed brand and reference-style logo match |
| P02 | Suspicious mismatch | Brand presentation mismatch and urgency language |
| P03 | Legitimate alternative layout | Legitimate-style page with a different layout |
| P04 | Missing logo | Visual evidence is unavailable or incomplete |

## How to run
From this directory, run:

```bash
python -m http.server 8000
```

Open each page in a browser:

- http://localhost:8000/test_pages/P01_legitimate_match.html
- http://localhost:8000/test_pages/P02_suspicious_mismatch.html
- http://localhost:8000/test_pages/P03_legitimate_layout.html
- http://localhost:8000/test_pages/P04_missing_logo.html

Stop the server with `Ctrl+C`.

## Evidence and limitations
Each page includes a page ID, an intended URL, and a claimed-brand label in HTML data attributes. These are test-fixture metadata, not proof of legitimacy. A detector should use the intended URL for its test context rather than treating `localhost` as suspicious.

`proposed_shared_evidence_schema.json` is a proposed schema for coordination with the fusion-module owner. Confirm field names and types with the team before integration.

`expected_results.json` contains hypotheses for testing, not measured detector results. Update it only after running the implementation and recording actual observations.

The pages use fictional brands and reserved `.example` URLs. Forms are illustrative and do not transmit or store submitted information. No real credentials, cookies, or sensitive input values should be collected.

## Suggested MCR II evidence
1. Screenshot of each local test page.
2. Test inventory and intended outcome.
3. Actual module output for each page, once available.
4. One successful case and one difficult or incomplete-evidence case.
5. Any discrepancies between expected and observed output.

## Status
Initial controlled fixtures prepared. Detector execution and measured results must be documented separately.
