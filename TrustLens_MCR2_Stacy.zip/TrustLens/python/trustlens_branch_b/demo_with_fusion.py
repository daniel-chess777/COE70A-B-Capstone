"""End-to-end check: Branch B -> shared format -> Derek's fusion (schema v0.1.0).

    python3 demo_with_fusion.py /path/to/trustlens_fusion

The visual branch is sent as status "missing" (not connected yet), so fusion
works from the url / dom / text branches only.
"""
import sys

from url_html_text_branch import analyze
from shared_adapter import to_shared
from test_branch import LEGIT, PHISH, SSO

PAD = "<p>" + "Account services information and support content. " * 8 + "</p>"
CASES = [
    ("L-03 legitimate PayPal login", "https://www.paypal.com/signin", LEGIT),
    ("P-01 phishing-style PayPal", "http://paypal-secure-login.evil-site.xyz/login", PHISH),
    ("SSO portal (Sign in with Microsoft)", "https://portal.acme.com/", SSO),
    ("Typosquat paypa1.com", "https://paypa1.com/signin", "<title>PayPal</title>" + PAD + "<form action='/x'><input type='password'></form>"),
    ("Evasive: clean domain, no brand", "https://secure-docs.example.net/view", PAD + "<form action='/s'><input type='password'></form>"),
]

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    sys.path.insert(0, sys.argv[1])
    from fusion import fuse  # noqa: E402
    visual = {"schema_version": "0.1.0", "branch": "visual", "status": "missing", "missing_flags": ["vis.not_connected"]}
    for name, url, html in CASES:
        r = analyze(url, html)
        shared = to_shared(r, request_id=name, page_id=name)
        out = fuse({"schema_version": "0.1.0", "request_id": name, "branches": shared + [visual]})
        print(f"\n{name}\n  Branch B {r['risk_score']} ({r['label_hint']})  ->  fusion {out['decision'].upper()}"
              f"  p={out['p_fused']}  coverage={out['uncertainty']['coverage']}"
              + (f"  reasons={out['uncertainty']['reasons']}" if out['uncertainty']['reasons'] else ""))
        print("  p_phish sent:", {b["branch"]: b["p_phish"] for b in shared})
        for x in out["explanations"]:
            print(f"  - [{x['contribution']:+.2f}] {x['text']}")
