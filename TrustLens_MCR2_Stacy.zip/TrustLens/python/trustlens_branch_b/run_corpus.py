"""Run Branch B over a corpus folder described by manifest.json (MCR II).

    python3 run_corpus.py ../../corpus_example            # table + summary
    python3 run_corpus.py ../../corpus_example --shared   # also write <id>/branch_b_shared.json

manifest.json is a list of pages:
  {"id", "label" (0 legit / 1 phishing-style), "intended_url", "claimed_brand",
   "page" (path to the HTML), "screenshot", "viewport", "expected_evidence": [ids]}

Each page is analyzed as if served from localhost with its intended_url passed in,
exactly as the extension sees a fixture. The report lists, per page, the score,
the label hint, the evidence found, and any expected evidence that did NOT fire.
"""
import json
import os
import sys

from url_html_text_branch import analyze
from shared_adapter import to_shared


def run(folder, write_shared=False):
    with open(os.path.join(folder, "manifest.json"), encoding="utf-8") as f:
        manifest = json.load(f)
    tp = fp = tn = fn = 0
    rows = []
    for item in manifest:
        with open(os.path.join(folder, item["page"]), encoding="utf-8") as f:
            html = f.read()
        local = "http://127.0.0.1:8000/" + item["page"]
        r = analyze(local, html, intended_url=item.get("intended_url"))
        found = [e["id"] for e in r["evidence"]]
        missed = [x for x in item.get("expected_evidence", []) if x not in found]
        pred = int(r["label_hint"] == "suspicious")
        y = item.get("label")
        if y is not None:
            tp += pred and y; fp += pred and not y; tn += (not pred) and not y; fn += (not pred) and y
        rows.append((item["id"], r["risk_score"], r["label_hint"], r["url_source"], found, missed))
        if write_shared:
            out = os.path.join(folder, item["id"], "branch_b_shared.json")
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with open(out, "w", encoding="utf-8") as f:
                json.dump(to_shared(r, request_id="corpus-" + item["id"], page_id=item["id"]), f, indent=1)
    for pid, score, hint, src, found, missed in rows:
        print(f"{pid:6} {score:.3f} {hint:10} [{src}]")
        print(f"       evidence: {', '.join(found) or 'none'}")
        if missed:
            print(f"       EXPECTED BUT MISSING: {', '.join(missed)}")
    n = tp + fp + tn + fn
    if n:
        p = tp / (tp + fp) if tp + fp else 0.0
        rc = tp / (tp + fn) if tp + fn else 0.0
        print(f"\n{n} labelled pages: TP={tp} FP={fp} TN={tn} FN={fn} precision={p:.2f} recall={rc:.2f}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    run(sys.argv[1], "--shared" in sys.argv)
