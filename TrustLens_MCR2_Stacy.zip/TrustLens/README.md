# COE70A-B-Capstone — TrustLens

TrustLens is a phishing-triage Chrome extension. This repo combines:

- **Cristian's extension prototype (MCR1):** popup, "Scan this page", saved scan files (`scan.json`, `page.html.txt`, `screenshot.png`) and a low/medium/high triage score. The write-up and sample scans are in `deliverables/cristian_mcr1/`.
- **Stacy's Branch B (MCR1):** URL, HTML/DOM and visible-text analysis with unit tests and an evaluation corpus. The original Python is in `python/trustlens_branch_b/`. A JavaScript port runs inside the extension.

## Layout

```
extension/                  Load this folder in chrome://extensions ("Load unpacked")
  manifest.json             MV3; permissions: activeTab, scripting, downloads
  popup.html/.css/.js       Popup: scan, show both results, save files
  lib/collect.js            Runs in the page and gathers the scan.json indicators + HTML
  lib/heuristics.js         Prototype points score -> low / medium / high
  lib/branch_b.js           Branch B analyzer (JS port of url_html_text_branch.py)
  lib/html_parser.js        Tokenizer matching Python's html.parser
  lib/pyport.js             difflib ratio, urlparse, unquote, parse_qs ports
  selftest/                 Branch B tests + evaluation, runnable inside the extension
python/trustlens_branch_b/  Stacy's original Python module, tests, evaluate.py
tests/                      Node test runner (unit, parity, heuristics)
deliverables/cristian_mcr1/ Prototype write-up PDF + saved nike.com / adidas.ca scans
```

## Using the extension

1. Open `chrome://extensions`, turn on Developer mode, then click **Load unpacked** and pick the `extension/` folder.
2. On any http(s) page, click the TrustLens icon and then **Scan this page**. The popup shows:
   - **Prototype triage**: points, level and reasons.
   - **Branch B**: `risk_score`, `label_hint`, `confidence`, `missing` and the weighted evidence list.
3. With "Save scan files" ticked, the files go to `Downloads/PhishScans/<host>_<timestamp>/`. `scan.json` now also holds `heuristics` and `branchB`, the shared branch-schema output for fusion.
4. Click **Run self-tests** in the popup to run Branch B's unit tests and evaluation corpus inside Chrome. These use the same analyzer code the popup uses.

## Tests

```
npm test          # JS: Branch B unit tests, Python<->JS parity, prototype heuristics
npm run test:py   # Python: Stacy's original unittest suite
npm run evaluate  # Branch B precision / recall / FPR (JS port of evaluate.py)
```

- `tests/branch_b.test.js` runs the same cases as the in-extension self-test page (`extension/selftest/branch_b.cases.js`). These are a 1:1 port of `test_branch.py`.
- `tests/parity.test.js` checks that the JS analyzer gives the same evidence, weights and scores as the Python one. It covers 29 cases, including Cristian's real nike.com and adidas.ca pages. **If you change the Python analyzer, make the same change in `extension/lib/branch_b.js`, then run `npm run parity:update`**. The test fails if the two drift apart.
- `tests/heuristics.test.js` checks that the prototype score reproduces the scores stored in Cristian's saved scans.

No dependencies: Node 18+ and Python 3 standard library only.

## MCR II additions (Stacy, Branch B)

- **Local test fixtures and the intended URL.** A fixture served from `localhost`, `127.0.0.1` or `file://` declares the URL it imitates with
  `<meta name="trustlens:intended-url" content="https://...">`, or the corpus manifest passes `intended_url`. Branch B then runs its URL/domain rules on that URL, so localhost is never the evidence. The output records `analyzed_url` and `url_source` (`page`, `manifest`, `fixture_meta`, `local_unscored`). The tag is ignored on public hosts and reported as `html.fixture_tag_on_public_page`, so a real phishing page can't use it to pose as another site.
- **Shared evidence format.** `shared_adapter.py` / `extension/lib/shared_adapter.js` convert Branch B output into fusion schema v0.1.0 (Derek): one object each for the `url`, `dom` and `text` branches. Evidence with no fusion type yet is kept in `features`. The popup now saves this as `branchBShared` in `scan.json`, with a `requestId`.
- **Corpus runner.** `python3 python/trustlens_branch_b/run_corpus.py corpus_example --shared` runs Branch B over a folder described by `manifest.json`. It flags expected evidence that didn't fire and writes each page's shared-format JSON. `corpus_example/` shows the layout for Daniel's corpus.
- **End to end with fusion.** `python3 python/trustlens_branch_b/demo_with_fusion.py <path to trustlens_fusion>` sends Branch B output through Derek's `fuse()`.
- **New rule `html.shortened_link`.** Links inside a page that go through a URL shortener (bit.ly, tinyurl.com, ...) are reported once per page: 0.15, plus 0.05 per extra link, capped at 0.3.
- **Tests.** 34 Python tests (14 original + 20 MCR II) and 73 JS tests (unit, MCR II, parity on 35 inputs including the adapter output, heuristics).
