// MCR II tests (Stacy Nwankwo), port of python/trustlens_branch_b/test_mcr2.py:
// local fixtures + intended URL, shared-format adapter, Week 6-7 cases.
import { analyze, isLocal } from "../lib/branch_b.js";
import { toShared } from "../lib/shared_adapter.js";
import { LEGIT, PHISH, SSO } from "./fixtures.js";

const PAD_TEXT = "<p>" + "Account services information and support content. ".repeat(8) + "</p>";
const PHISH_URL = "http://paypal-secure-login.evil-site.xyz/login";
const LEGIT_URL = "https://www.paypal.com/signin";
const tag = (u) => `<meta name="trustlens:intended-url" content="${u}">`;
const ids = (r) => new Set(r.evidence.map((e) => e.id));
const byBranch = (s) => Object.fromEntries(s.map((b) => [b.branch, b]));

export const mcr2Cases = [
  ["fixture on localhost scores like its intended URL", (t) => {
    const served = analyze("http://localhost:8000/P-01/page.html", tag(PHISH_URL) + PHISH);
    const direct = analyze(PHISH_URL, PHISH);
    t.equal(served.url_source, "fixture_meta"); t.equal(served.analyzed_url, PHISH_URL);
    t.equal(served.risk_score, direct.risk_score);
    t.deepEqual([...ids(served)].sort(), [...ids(direct)].sort());
    t.includes(ids(served), "url.brand_in_domain");
  }],
  ["legit fixture on 127.0.0.1 scores like its intended URL", (t) => {
    const served = analyze("http://127.0.0.1:8000/L-03/page.html", tag(LEGIT_URL) + LEGIT);
    t.equal(served.risk_score, analyze(LEGIT_URL, LEGIT).risk_score);
    t.notIncludes(ids(served), "url.no_https");
  }],
  ["localhost without tag is never URL evidence", (t) => {
    const r = analyze("http://localhost:8000/legit.html", LEGIT);
    t.equal(r.url_source, "local_unscored"); t.includes(r.missing, "url");
    t.deepEqual([...ids(r)].filter((i) => i.startsWith("url.")), []);
  }],
  ["manifest intended URL wins", (t) => {
    const r = analyze("http://localhost:8000/x.html", LEGIT, null, { intendedUrl: LEGIT_URL });
    t.deepEqual([r.url_source, r.analyzed_url], ["manifest", LEGIT_URL]);
  }],
  ["fixture tag on a public host is ignored and flagged", (t) => {
    const r = analyze(PHISH_URL, tag(LEGIT_URL) + PHISH);
    t.equal(r.url_source, "page"); t.equal(r.analyzed_url, PHISH_URL);
    t.includes(ids(r), "html.fixture_tag_on_public_page");
  }],
  ["local hosts", (t) => {
    for (const u of ["http://localhost/a", "http://127.0.0.1:8000/", "file:///tmp/p.html", "http://app.localhost/"]) t.ok(isLocal(u), u);
    for (const u of ["https://www.paypal.com/", "http://203.0.113.9/", "http://localhost.evil.com/"]) t.ok(!isLocal(u), u);
  }],
  ["adapter: phish maps to fusion types", (t) => {
    const s = byBranch(toShared(analyze(PHISH_URL, PHISH), { requestId: "tab1-nav1", pageId: "P-01" }));
    t.deepEqual(Object.keys(s).sort(), ["dom", "text", "url"]);
    for (const b of Object.values(s)) {
      t.deepEqual([b.schema_version, b.request_id, b.page_id, b.status], ["0.1.0", "tab1-nav1", "P-01", "ok"]);
      t.ok(b.p_phish >= 0.05 && b.p_phish <= 0.99);
      for (const e of b.evidence) { t.ok(e.verified); t.ok("kind" in e.locator); }
    }
    const dom = Object.fromEntries(s.dom.evidence.map((e) => [e.type, e]));
    t.deepEqual(dom.form_action_mismatch.fields, { page_domain: "evil-site.xyz", action_domain: "other-site.xyz" });
    t.equal(dom.misleading_link_destination.fields.displayed_domain, "paypal.com");
    t.equal(dom.misleading_link_destination.fields.actual_domain, "evil-site.xyz");
    t.ok(dom.credential_solicitation);
    t.deepEqual(s.url.claims, { domain: "evil-site.xyz", domain_owner_brand: null });
    t.equal(s.text.claims.brand, "paypal");
    t.ok("url.suspicious_tld" in s.url.features);
  }],
  ["adapter: legit claims match owner", (t) => {
    const s = byBranch(toShared(analyze(LEGIT_URL, LEGIT)));
    t.equal(s.url.claims.domain_owner_brand, "paypal"); t.equal(s.dom.claims.brand, "paypal");
    t.deepEqual(Object.values(s).flatMap((b) => b.evidence).filter((e) => e.type === "brand_domain_mismatch"), []);
  }],
  ["adapter: SSO page claims no brand", (t) => {
    const s = byBranch(toShared(analyze("https://portal.acme.com/", SSO)));
    t.deepEqual(s.text.claims, {});
    t.deepEqual(s.text.evidence.filter((e) => e.type === "credential_solicitation"), []);
  }],
  ["adapter: missing branches", (t) => {
    const s = byBranch(toShared(analyze("http://localhost:8000/x.html", null)));
    t.deepEqual([s.url.status, s.dom.status, s.text.status], ["missing", "missing", "missing"]);
    t.equal(s.url.p_phish, null);
  }],
  ["dynamic form needs rendered HTML", (t) => {
    const raw = "<p>Sign in to continue.</p><div id=f></div><script>f.innerHTML='<input type=password>'</script>";
    t.notIncludes(ids(analyze("https://a.com/", raw)), "html.password_form");
    const rendered = "<p>Sign in to continue.</p><div id=f><form action='http://x.top/p'><input type=password></form></div>";
    t.subset(["html.password_form", "html.cross_domain_form", "html.insecure_form"], ids(analyze("https://a.com/", rendered)));
  }],
  ["hidden links", (t) => {
    const h = [0, 1, 2].map((i) => `<a href='http://e${i}.com' style='display:none'>x</a>`).join("");
    t.includes(ids(analyze("https://a.com/", h)), "html.hidden_links");
  }],
  ["URL obfuscation", (t) => {
    const u = "https://secure-login.example.com/%61%63%63%6f%75%6e%74/" + "a".repeat(90);
    t.subset(["url.encoded_chars", "url.long"], ids(analyze(u)));
  }],
  ["shortened links inside page", (t) => {
    const h = PAD_TEXT + "<a href='https://bit.ly/3xYz'>Verify here</a><a href='https://tinyurl.com/abc'>Help</a>";
    const e = analyze("https://a.com/", h).evidence.filter((x) => x.id === "html.shortened_link");
    t.equal(e.length, 1);
    t.deepEqual(e[0].detail, { count: 2, domains: ["bit.ly", "tinyurl.com"] });
    t.equal(e[0].weight, 0.2);
  }],
  ["normal links not shortened", (t) => {
    const h = PAD_TEXT + "<a href='https://www.paypal.com/help'>Help</a><a href='/about'>About</a>";
    t.notIncludes(ids(analyze("https://a.com/", h)), "html.shortened_link");
  }],
  ["shortened link alone stays safe", (t) => {
    t.equal(analyze("https://blog.example.org/post", PAD_TEXT + "<a href='https://bit.ly/x'>slides</a>").label_hint, "safe");
  }],
  ["logo and form only", (t) => {
    const h = "<img src='logo.png' alt=''><form action='/s'><input type='email'><input type='password'><button>Next</button></form>";
    const r = analyze("https://a.com/", h);
    t.includes(r.missing, "limited_visible_text"); t.equal(r.confidence, 0.8);
    t.includes(ids(r), "text.limited_with_form");
  }],
  ["mostly hidden text counts as limited", (t) => {
    const hidden = "<div style='display:none'>" + "Lots of legitimate looking filler text here. ".repeat(20) + "</div>";
    const r = analyze("https://a.com/", "<p>Sign in</p>" + hidden + "<form><input type='password'></form>");
    t.includes(r.missing, "limited_visible_text"); t.includes(ids(r), "text.limited_with_form");
  }],
  ["little text without form has no form evidence", (t) => {
    const r = analyze("https://a.com/", "<h1>Coming soon</h1>");
    t.includes(r.missing, "limited_visible_text"); t.notIncludes(ids(r), "text.limited_with_form");
  }],
  ["enough text not limited", (t) => {
    const r = analyze("https://a.com/", PAD_TEXT + "<form><input type='password'></form>");
    t.notIncludes(r.missing, "limited_visible_text"); t.equal(r.confidence, 1.0);
  }],
];
