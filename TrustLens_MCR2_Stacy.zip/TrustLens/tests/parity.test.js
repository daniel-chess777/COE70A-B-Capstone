// The extension's JavaScript Branch B must agree with Stacy's Python Branch B.
// Expected outputs come from tests/gen_parity_fixtures.py (Python), including
// Cristian's real captured pages (deliverables/cristian_mcr1/TrustlensProtoScans).
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { analyze } from "../extension/lib/branch_b.js";
import { toShared } from "../extension/lib/shared_adapter.js";

const root = new URL("../", import.meta.url);
const fixtures = JSON.parse(readFileSync(new URL("tests/fixtures/branch_b_parity.json", root), "utf8"));

const close = (a, b) => Math.abs(a - b) < 1e-9 + 1e-3;

for (const fx of fixtures) {
  test(`parity: ${fx.name}`, () => {
    const html = fx.htmlFile ? readFileSync(new URL(fx.htmlFile, root), "utf8") : fx.html;
    const got = analyze(fx.url, html);
    const exp = fx.expected;
    assert.equal(got.branch, exp.branch);
    assert.equal(got.label_hint, exp.label_hint);
    assert.deepEqual(got.missing, exp.missing);
    assert.ok(close(got.risk_score, exp.risk_score), `risk_score ${got.risk_score} vs ${exp.risk_score}`);
    assert.ok(close(got.confidence, exp.confidence), `confidence ${got.confidence} vs ${exp.confidence}`);
    assert.deepEqual(
      got.evidence.map((e) => [e.id, e.modality, e.weight, e.description, e.detail]),
      exp.evidence.map((e) => [e.id, e.modality, e.weight, e.description, e.detail]),
    );
    assert.equal(got.analyzed_url, exp.analyzed_url);
    assert.equal(got.url_source, exp.url_source);
    assert.deepEqual(got.claims, exp.claims);
    // shared-format adapter (fusion schema v0.1.0) must agree too
    assert.deepEqual(JSON.parse(JSON.stringify(toShared(got, { requestId: "req-1", pageId: fx.name }))), fx.shared);
  });
}
