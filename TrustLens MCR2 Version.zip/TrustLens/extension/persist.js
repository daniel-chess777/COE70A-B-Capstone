// Keeps the last scan result for each tab so the popup can show it again after
// it is closed and reopened. popup.js is not modified: this file watches the
// result elements popup.js renders into, saves what they show to
// chrome.storage.session (cleared when the browser closes), and restores it
// when the popup opens on the same tab and URL. The Scan button is never
// touched, so a rescan works as before and replaces the saved result.

const $ = (id) => document.getElementById(id);
const TEXT_IDS = ["protoScore", "bScore", "bConf", "bMissing"];
const PILL_IDS = ["protoLevel", "bLabel"];
const LIST_IDS = ["protoFlags", "bEvidence"];
const keyFor = (tabId) => `scan:${tabId}`;

let tab;

function snapshot() {
  const data = { url: tab.url, savedAt: Date.now(), text: {}, pills: {}, lists: {} };
  for (const id of TEXT_IDS) data.text[id] = $(id).textContent;
  for (const id of PILL_IDS) data.pills[id] = { text: $(id).textContent, cls: $(id).className };
  for (const id of LIST_IDS) {
    data.lists[id] = [...$(id).children].map((li) => {
      const w = li.querySelector(".w");
      return { text: li.firstChild ? li.firstChild.textContent : "", weight: w ? w.textContent : null };
    });
  }
  const status = $("status").textContent;
  data.status = /^Saved to /.test(status) ? status : "";
  return data;
}

function restore(data) {
  for (const id of TEXT_IDS) $(id).textContent = data.text[id] ?? "";
  for (const id of PILL_IDS) {
    $(id).textContent = data.pills[id]?.text ?? "";
    $(id).className = data.pills[id]?.cls ?? "pill";
  }
  for (const id of LIST_IDS) {
    $(id).replaceChildren(...(data.lists[id] || []).map(({ text, weight }) => {
      const li = document.createElement("li");
      li.textContent = text;
      if (weight !== null) {
        const w = document.createElement("span");
        w.className = "w";
        w.textContent = weight;
        li.append(w);
      }
      return li;
    }));
  }
  showLastScan(data.savedAt);
  if (data.status && !$("status").textContent) $("status").textContent = data.status;
  $("results").hidden = false;
}

function showLastScan(savedAt) {
  const el = $("lastScan");
  const when = new Date(savedAt);
  el.textContent = `Last scanned ${when.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` +
    (when.toDateString() === new Date().toDateString() ? "" : ` on ${when.toLocaleDateString()}`) +
    ". Scan again to refresh.";
  el.hidden = false;
}

// Drop saved results for tabs that no longer exist.
async function prune() {
  const [all, tabs] = await Promise.all([chrome.storage.session.get(null), chrome.tabs.query({})]);
  const live = new Set(tabs.map((t) => keyFor(t.id)));
  const stale = Object.keys(all).filter((k) => k.startsWith("scan:") && !live.has(k));
  if (stale.length) await chrome.storage.session.remove(stale);
}

(async () => {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https?:/.test(tab.url || "")) return;

  const key = keyFor(tab.id);
  let restoring = true;
  let pending = false;

  // Save whenever popup.js renders new results or a "Saved to…" status.
  const observer = new MutationObserver((records) => {
    const lastScan = $("lastScan");
    if (records.every((r) => lastScan.contains(r.target))) return; // our own timestamp line
    if (restoring || $("results").hidden || pending) return;
    pending = true;
    queueMicrotask(() => {
      pending = false;
      const data = snapshot();
      showLastScan(data.savedAt);
      chrome.storage.session.set({ [key]: data }).catch(() => {});
    });
  });
  const watch = { childList: true, subtree: true, characterData: true, attributes: true };
  observer.observe($("results"), watch);
  observer.observe($("status"), { childList: true, subtree: true, characterData: true });

  try {
    const { [key]: saved } = await chrome.storage.session.get(key);
    // Only restore for the same page, and never over a scan the user already started.
    if (saved && saved.url === tab.url && $("results").hidden) restore(saved);
  } catch { /* nothing saved, or storage unavailable */ }
  observer.takeRecords();
  restoring = false;

  prune().catch(() => {});
})();
